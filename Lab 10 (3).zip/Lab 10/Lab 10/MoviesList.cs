﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_10
{
    [Serializable]
    public class MoviesList : IMoviesList
    {
        public Movie[] Movies { get; set;  } = new Movie[50];

        public void AddMovie(Movie movie)
        {
            if (_isMovieExists(movie)) return;

            var counter = 0;

            var flag = false;

            while (!flag)
            {
                if (Movies[counter] == null)
                {
                    Movies[counter] = movie;
                    flag = true;
                }

                counter++;
            }
        }

        public void AddMovies(Movie[] movies)
        {
            foreach (var movie in movies)
                AddMovie(movie);
        }

        public void DisplayList()
        {
            Console.WriteLine("Список произведений: ");

            foreach (var movie in Movies)
            {
                if (movie != null)
                {
                    Console.WriteLine(movie.ToString());
                }
            }
        }

        public void RemoveMovie(Movie movie)
        {
            for (int i = 0; i < Movies.Length; i++)
            {
                if (Movies[i] == movie)
                {
                    Movies[i] = null;
                    return;
                }
            }
        }

        public void RemoveMovieById(int id)
        {
            if (id < 0 || id >= Movies.Length) return;
            
            Movies[id] = null;
        }

        private bool _isMovieExists(Movie movie)
        {
            foreach (var movie2 in Movies)
                if (movie2 == movie) return true;

            return false;
        }

        public void RemoveBeforeYear(Type t, int year)
        {
            foreach (var movie in Movies)
            {
                if (movie != null && movie.GetType() == t && movie.Year.Year < year)
                {
                    RemoveMovie(movie);
                }
            }
        }
    }
}
