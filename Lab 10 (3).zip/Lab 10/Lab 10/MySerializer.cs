﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_10
{
    internal abstract class MySerializer
    {
        public abstract void Serialize(object @object, string fileName); //записываем
        public abstract T? Deserialize<T>(string fileName); //читаем
    }
}
