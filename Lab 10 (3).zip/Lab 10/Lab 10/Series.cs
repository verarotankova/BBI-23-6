﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_10
{
    [Serializable]
    public class Series : Movie
    {
        private int[,] SeriesAmount = new int[,] { };

        public Series()
        {
            
        }

        public Series(string title, string director, DateTime year, float rating, TimeSpan length, int[,] seriesAmount):base(title, director, year, rating, length)
        {
            SeriesAmount = seriesAmount;
        }

        public override string ToString()
        {
            var str = base.ToString();
            
            str += $"Количество cерий: {SeriesAmount.Length} ";

            return str;
        }

        public TimeSpan GetSumTimeOfMovies()
        {
            var totalSeriesMinutes = 0;
            foreach (var movie in SeriesAmount)
            {
                totalSeriesMinutes += movie;
            }
            
            return TimeSpan.FromMinutes(totalSeriesMinutes);
        }
    }
}
