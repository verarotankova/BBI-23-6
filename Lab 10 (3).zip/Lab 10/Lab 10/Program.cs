﻿using System;

namespace Lab_10
{
    public class Program
    {
        public static void Main()
        {
            var movieLists = new MoviesList[]
            { 
                new MoviesList(),
                new MoviesList(),
                new MoviesList()
            };
            
            var movies = new Movie[] 
            {
                new Movie("Кролик Джоджо", "Тайка Вайтити", new DateTime(2020, 1, 23), 7.9f, new TimeSpan(1, 48, 0)),
                new Movie("Зеленая книга", "Питер Фаррелли", new DateTime(2019, 1, 24), 8.2f, new TimeSpan(2, 10, 0)),
                new Movie("Один дома", "Крис Коламбус", new DateTime(2050, 12, 20), 7.6f, new TimeSpan(1, 43, 0)),
                new Movie("Назад в будущее", "Роберт Земекис", new DateTime(1985, 10, 25), 8.5f, new TimeSpan(1, 56, 0)),
                new Movie("Начало", "Кристофер Нолан", new DateTime(2010, 7, 22), 8.8f, new TimeSpan(2, 28, 0)),
                new Movie("Побег из Шоушенка", "Фрэнк Дарабонт", new DateTime(1995, 2, 17), 9.3f, new TimeSpan(2, 22, 0)),
                new Movie("Список Шиндлера", "Стивен Спилберг", new DateTime(1994, 3, 11), 8.9f, new TimeSpan(3, 15, 0)),
                new Movie("Интерстеллар", "Кристофер Нолан", new DateTime(2050, 11, 6), 8.6f, new TimeSpan(2, 49, 0)),
                new Movie("Матрица", "Лана и Лилли Вачовски", new DateTime(1999, 3, 31), 8.7f, new TimeSpan(2, 16, 0)),
                new Movie("Форрест Гамп", "Роберт Земекис", new DateTime(1994, 7, 6), 8.8f, new TimeSpan(2, 22, 0)),
                new Movie("Гладиатор", "Ридли Скотт", new DateTime(2050, 5, 1), 8.5f, new TimeSpan(2, 35, 0)),
                new Movie("Титаник", "Джеймс Кэмерон", new DateTime(1997, 12, 19), 7.8f, new TimeSpan(3, 14, 0)),
                new Movie("Властелин колец: Братство Кольца", "Питер Джексон", new DateTime(2001, 12, 19), 8.8f, new TimeSpan(2, 58, 0)),
                new Movie("Властелин колец: Две крепости", "Питер Джексон", new DateTime(2002, 12, 18), 8.7f, new TimeSpan(2, 59, 0)),
                new Movie("Властелин колец: Возвращение короля", "Питер Джексон", new DateTime(2003, 12, 17), 8.9f, new TimeSpan(3, 21, 0)),
                new Movie("Звездные войны: Эпизод IV - Новая надежда", "Джордж Лукас", new DateTime(1977, 5, 25), 8.6f, new TimeSpan(2, 1, 0)),
                new Movie("Челюсти", "Стивен Спилберг", new DateTime(2050, 6, 20), 8.0f, new TimeSpan(2, 4, 0)),
                new Movie("Терминатор 2: Судный день", "Джеймс Кэмерон", new DateTime(1991, 7, 3), 8.5f, new TimeSpan(2, 17, 0)),
                new Movie("Крестный отец", "Фрэнсис Форд Коппола", new DateTime(1972, 3, 24), 9.2f, new TimeSpan(2, 55, 0)),
                new Movie("Крестный отец 2", "Фрэнсис Форд Коппола", new DateTime(2050, 12, 20), 9.0f, new TimeSpan(3, 22, 0))
            };

            var series = new Series[]
            {
                new Series("Игра престолов", "Дэвид Бениофф, Д. Б. Уайсс", new DateTime(2011, 4, 17), 9.2f, new TimeSpan(1, 0, 0), new int[,] { { 10, 10, 10 }, { 10, 10, 10 }, {10, 7, 6 } } ),
                new Series("Во все тяжкие", "Винс Гиллиган", new DateTime(2050, 1, 20), 9.5f, new TimeSpan(0, 47, 0), new int[,] { { 7, 13 }, {13, 13}}),
                new Series("Шерлок", "Марк Гэтисс, Стивен Моффат", new DateTime(2010, 7, 25), 9.1f, new TimeSpan(1, 28, 0), new int[,] { { 3, 3 }, {3, 3 }}),
                new Series("Черное зеркало", "Чарли Брукер", new DateTime(2011, 12, 4), 8.8f, new TimeSpan(1, 0, 0), new int[,] { { 3, 3, 6 }, { 6, 3 , 2 }}),
                new Series("Очень странные дела", "Мэтт Даффер, Росс Даффер", new DateTime(2016, 7, 15), 8.7f, new TimeSpan(0, 50, 0), new int[,] { { 8, 9 }, {8, 9 }}),
                new Series("Фарго", "Ноа Хоули", new DateTime(2050, 4, 15), 8.9f, new TimeSpan(0, 53, 0), new int[,] { { 10, 10, 10 }, { 11, 10 , 11 }}),
                new Series("Настоящий детектив", "Ник Пиццолатто", new DateTime(2014, 1, 12), 9.0f, new TimeSpan(0, 55, 0), new int[,] { { 8, 8, 8, 8 }}),
                new Series("Доктор Кто", "Сидни Ньюман", new DateTime(2005, 3, 26), 8.6f, new TimeSpan(0, 45, 0), new int[,] { { 13, 13, 13, 18 }, { 13, 13, 14, 13 }, { 12, 12, 12, 10 }, { 11, 12, 10, 7 }}),
                new Series("Остаться в живых", "Дж. Дж. Абрамс, Деймон Линделоф", new DateTime(2004, 9, 22), 8.3f, new TimeSpan(0, 44, 0), new int[,] { { 25, 24 }, { 23, 14 }, {17, 18 }}),
                new Series("Мир Дикого Запада", "Лиза Джой, Джонатан Нолан", new DateTime(2016, 10, 2), 8.6f, new TimeSpan(1, 0, 0), new int[,] { { 10, 10 }, {8, 8 }}),
                new Series("Друзья", "Дэвид Крейн, Марта Кауффман", new DateTime(1994, 9, 22), 8.9f, new TimeSpan(0, 22, 0), new int[,] { { 24, 24, 25 }, { 24, 24, 25 }, { 24, 24, 24 }}),
                new Series("Сверхъестественное", "Эрик Крипке", new DateTime(2050, 9, 13), 8.4f, new TimeSpan(0, 42, 0), new int[,] { { 22, 22, 16, 22 }, { 22, 22, 23, 23 }, { 23, 23, 23, 20 }, {23, 20, 20, 11 }}),
                new Series("Теория большого взрыва", "Чак Лорри, Билл Прэди", new DateTime(2007, 9, 24), 8.2f, new TimeSpan(0, 22, 0), new int[,] { { 17, 23, 23 }, { 24, 24, 24 }, { 24, 24, 24 }, {24, 24, 24 }}),
                new Series("Симпсоны", "Мэтт Грейнинг", new DateTime(2050, 12, 17), 8.7f, new TimeSpan(0, 22, 0), new int[,] { { 13, 22, 24, 22, 25 }, { 25, 25, 24, 25, 23 }, { 22, 22, 22, 22, 22 }, { 21, 22, 22, 22, 21 }, { 23, 22, 22, 22, 22 }}),
                new Series("Американская история ужасов", "Райан Мёрфи, Брэд Фэлчак", new DateTime(2011, 10, 5), 8.0f, new TimeSpan(0, 45, 0), new int[,] { { 12, 13, 13 }, { 13, 12, 10 }, {11, 10, 9}}),
                new Series("Бесстыдники", "Пол Эбботт", new DateTime(2011, 1, 9), 8.6f, new TimeSpan(0, 46, 0), new int[,] { { 12, 12, 12 }, { 12, 12, 12 }, {12, 12, 14}}),
                new Series("Лучше звоните Солу", "Винс Гиллиган, Питер Гулд", new DateTime(2015, 2, 8), 8.7f, new TimeSpan(0, 47, 0), new int[,] { { 10, 10 }, { 10, 10 }}),
                new Series("Ходячие мертвецы", "Фрэнк Дарабонт", new DateTime(2010, 10, 31), 8.2f, new TimeSpan(0, 44, 0), new int[,] { { 6, 13, 16 }, { 16, 16, 16 }, { 16, 16, 16 }}),
                new Series("Половое воспитание", "Лори Нанн", new DateTime(2050, 1, 11), 8.3f, new TimeSpan(0, 50, 0), new int[,] { { 8, 8 }, {8, 8 }}),
                new Series("Домашний арест", "Семён Слепаков", new DateTime(2018, 7, 16), 8.1f, new TimeSpan(0, 25, 0), new int[,] { { 12 }})
            };

            foreach (var moviesList in movieLists)
                _addRandomMoviesToArray(moviesList, movies, 5);

            foreach (var moviesList in movieLists)
                _addRandomMoviesToArray(moviesList, series, 1);

  


            var jsonSerializer = new MyJsonSerializer();

            jsonSerializer.Serialize(movieLists, "raw_data.json");

            foreach (var moviesList in movieLists)
                Movie.SortByDate(moviesList.Movies);
            
            jsonSerializer.Serialize(movieLists, "data.json");

            foreach (var moviesList in movieLists)
                _addRandomMoviesToArray(moviesList, series, 3);

            foreach (var moviesList in movieLists)
                Movie.SortByTitle(moviesList.Movies);

            jsonSerializer.Serialize(movieLists, "sort_data.json");


            var movieLists0 = jsonSerializer.Deserialize<MoviesList[]>("raw_data.json");
            var movieLists1 = jsonSerializer.Deserialize<MoviesList[]>("data.json");
            var movieLists2 = jsonSerializer.Deserialize<MoviesList[]>("sort_data.json");


            Console.WriteLine("Неотсортированный каталог");
            foreach (var list in movieLists0)
                list.DisplayList();
            Console.WriteLine();

            Console.WriteLine("Фильмы отсортированные от старых к новым");
            foreach (var list in movieLists1)
                list.DisplayList();
            Console.WriteLine();

            Console.WriteLine("+3 сериала и отсортируйте по названию");
            foreach (var list in movieLists2)
                list.DisplayList();
            Console.WriteLine();

            var xmlSerializer = new MyXmlSerializer();

            // Сериализация в XML

            foreach (var moviesList in movieLists)
            {
                moviesList.RemoveBeforeYear(typeof(Movie), 2020);
            }
            foreach (var moviesList in movieLists)
            {
                moviesList.RemoveBeforeYear(typeof(Series), 2021);
            }
            
            xmlSerializer.Serialize(movieLists, "raw_data.xml");

            
            var cartoons = new Cartoon[]
            {
                new Cartoon("Тайна Коко", "Ли Анкрич", new DateTime(2017, 11, 22), 8.4f, new TimeSpan(1, 45, 0), 6, "Компьютерная анимация"),
                new Cartoon("Зверополис", "Байрон Ховард", new DateTime(2016, 2, 11), 8.0f, new TimeSpan(1, 48, 0), 6, "Компьютерная анимация"),
                new Cartoon("Холодное сердце", "Крис Бак", new DateTime(2013, 11, 27), 7.4f, new TimeSpan(1, 42, 0), 0, "Компьютерная анимация"),
                new Cartoon("Головоломка", "Пит Доктер", new DateTime(2015, 5, 18), 8.1f, new TimeSpan(1, 35, 0), 6, "Компьютерная анимация"),
                new Cartoon("Король Лев", "Роджер Аллерс", new DateTime(1994, 6, 15), 8.5f, new TimeSpan(1, 28, 0), 0, "Рисованная анимация"),
                new Cartoon("Тайна Келлс", "Томм Мур", new DateTime(2009, 2, 9), 7.7f, new TimeSpan(1, 15, 0), 6, "Рисованная анимация"),
                new Cartoon("Кунг-фу Панда", "Марк Осборн", new DateTime(2008, 6, 6), 7.6f, new TimeSpan(1, 32, 0), 6, "Компьютерная анимация"),
                new Cartoon("Рататуй", "Брэд Берд", new DateTime(2007, 6, 29), 8.0f, new TimeSpan(1, 51, 0), 6, "Компьютерная анимация"),
                new Cartoon("Жизнь кабачка", "Клод Баррас", new DateTime(2016, 5, 15), 7.7f, new TimeSpan(1, 6, 0), 12, "Кукольная анимация"),
                new Cartoon("Как приручить дракона", "Крис Сандерс", new DateTime(2010, 3, 26), 8.1f, new TimeSpan(1, 38, 0), 6, "Компьютерная анимация")
            };

            foreach (var moviesList in movieLists)
                _addRandomMoviesToArray(moviesList, cartoons, 5);
            
            xmlSerializer.Serialize(movieLists, "data.xml");



            var allMovies = new MoviesList();
            allMovies.AddMovies(movies);
            allMovies.AddMovies(series);
            allMovies.AddMovies(cartoons);
            Movie.SortByDate(allMovies.Movies);
            
            xmlSerializer.Serialize(allMovies, "sort_data.xml");
            

            var movieListsXml0 = xmlSerializer.Deserialize<MoviesList[]>("raw_data.xml");
            var movieListsXml1 = xmlSerializer.Deserialize<MoviesList[]>("data.xml");
            var movieListsXml2 = xmlSerializer.Deserialize<MoviesList>("sort_data.xml");


            Console.WriteLine("Без фильмов до 2020 и сериалов до 2021 года");
            foreach (var list in movieListsXml0)
                list.DisplayList();
            Console.WriteLine();
            
            Console.WriteLine("Добавлены мультики");
            foreach (var list in movieListsXml1)
                list.DisplayList();
            Console.WriteLine();

            Console.WriteLine("Все фильмы отсортированные по дате");
            movieListsXml2.DisplayList();

            
        }

        private static void _addRandomMoviesToArray(IMoviesList moviesList, Movie[] movies, int count)
        {
            var newMoviesArray = new Movie[count];

            var counter = 0;

            while (counter != count)
            {
                var randomId = new Random().Next(0, movies.Length);

                var movie = movies[randomId];

                if (movie != null)
                {
                    newMoviesArray[counter] = movie;
                    // movies[randomId] = null;

                    counter++;
                }
            }

            moviesList.AddMovies(newMoviesArray);
        }

    }
}