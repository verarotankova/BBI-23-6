﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Lab_10
{
    internal class MyJsonSerializer : MySerializer
    {
        public override T? Deserialize<T>(string fileName) where T : default //читаем
        {
            string jsonFromFile = File.ReadAllText(fileName);
            return JsonConvert.DeserializeObject<T>(jsonFromFile);
        }

        public override void Serialize(object @object, string fileName) //записываем
        {
            var stringJson = JsonConvert.SerializeObject(@object);
            File.WriteAllText(fileName, stringJson);
        }
    }
}
