﻿using System;
using Lab_10;
using System.IO;
using Newtonsoft.Json;
using static System.Net.WebRequestMethods;

namespace Lab_10
{
    [Serializable]
    [JsonObject(MemberSerialization.OptIn)]
    public class Cartoon : Movie
    {
        public int AgeRating { get; set; }
        public string Style { get; set; }

        public Cartoon()
        {
        }

        internal Cartoon(string title, string director, DateTime year, float rating, TimeSpan length, int ageRating,
            string style) : base(title, director, year, rating, length)
        {
            AgeRating = ageRating;
            Style = style;
        }

        public override string ToString()
        {
            var str = base.ToString();

            str += $"Рисовка: {Style} ";
            str += $"Возрастной рейтинг: {AgeRating} ";

            return str;
        }
    }
}