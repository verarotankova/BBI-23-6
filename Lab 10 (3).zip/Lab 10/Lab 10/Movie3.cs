﻿using System;
namespace Lab_10
{
    public partial class Movie
    {
        public static Movie[] SelectByYear(Movie[] movies, int year)
        {
            var moviesByYear = new List<Movie>();
            
            foreach (Movie movie in movies)
            {
                if (movie != null && movie.Year.Year == year)
                {
                    moviesByYear.Add(movie);
                }
            }

            return moviesByYear.ToArray();
        }
    }
}
